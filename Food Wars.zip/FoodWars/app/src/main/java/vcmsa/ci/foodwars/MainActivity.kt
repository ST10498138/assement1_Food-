package vcmsa.ci.foodwars

import android.os.Bundle
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import org.w3c.dom.Text
import android.widget.Button

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        val txtintro = findViewById<TextView>(R.id.txtIntro)
        val editText = findViewById<EditText>(R.id.editText)
        val viewmenu = findViewById<TextView>(R.id.viewmenu)
        val btnSugg = findViewById<Button>(R.id.btnSugg)
        val btnClear = findViewById<Button>(R.id.btnClear)

        btnSugg.setOnClickListener {
            val meal = editText.text.toString().toLowerCase()
            when (meal) {
                "breakfast" -> viewmenu.text = "tea, eggs, crispy bacon, buttered toast and fresh mango juice"
                "mid-morning" -> viewmenu.text = "fruit smoothie, oatmeal with cream cheese"
                "lunch" -> viewmenu.text = "burger with fries"
                "afternoon snack" -> viewmenu.text = "yogurt with fresh berries, nuts and honey"
                "dinner" -> viewmenu.text = "pizza and pasta carbonara"
                "after dinner snack" -> viewmenu.text = "chips"
                else -> {
                    viewmenu.text = "Invalid suggestion"
                    editText.text.clear()
                    editText.requestFocus()
                }
            }
//

        }

        btnClear.setOnClickListener {
            editText.text.clear()
            viewmenu.text = ""
        }



        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
}